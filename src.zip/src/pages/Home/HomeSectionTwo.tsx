import React from 'react'

const HomeSectionTwo = () => {
    return (
        <div>HomeSectionTwo</div>
    )
}

export default HomeSectionTwo